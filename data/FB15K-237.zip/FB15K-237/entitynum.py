import os
import sys
import json
#with open('user_id_add.json', 'r',encoding='utf-8') as fuserid:
    #userid = json.load(fuserid)
re_list = {}
ent_list = {}
f0 = open("all_triples",encoding='utf-8')
line0 = f0.readline()
num = 0
while line0: 
    line0 = line0.strip('\n')
    en1,en2,rel= line0.split('\t')
    if en1 in ent_list:
        ent_list[en1] += 1
    else:
        ent_list[en1] = 1
    if en2 in ent_list:
        ent_list[en2] += 1
    else:
        ent_list[en2] = 1
    if rel in re_list:
        re_list[rel] += 1
    else:
        re_list[rel] = 1
    line0 = f0.readline()
    if num%1000000 == 0:
        print(num)
    num+=1
#print(re_list)
#print(len(re_list))
en_count = {}
rel_count = {}
en_count2 = {'1':0,'2':0,'3':0,'4':0,'5':0,'6':0,'7':0,'8':0,'9':0,'10':0,'20':0,'30':0,'40':0,'50':0,'60':0,'70':0,'80':0,'90':0,'100':0,'200':0,'300':0,'400':0,'500':0,'600':0,'700':0,'800':0,'900':0,'1000':0,'2000':0,'3000':0,'4000':0,'5000':0}
rel_count2 = {}
with open("rel_num.txt", 'a') as f: 
    for i in re_list:
        if str(re_list[i]) in rel_count:
            rel_count[str(re_list[i])] +=1
        else:
            rel_count[str(re_list[i])] = 1
    for i in rel_count:
        f.write(i + '\t' + str(rel_count[i])+'\n')
with open("en_num.txt", 'a') as f2: 
    for i in ent_list:
        if str(ent_list[i]) in en_count:
            en_count[str(ent_list[i])] +=1
        else:
            en_count[str(ent_list[i])] = 1
    for i in en_count:
        if int(i)<=10:
            en_count2[i] = en_count[i]
        elif int(i)>10 and int(i)<=20:
            en_count2['20'] += en_count[i]
        elif int(i)>20 and int(i)<=30:
            en_count2['30'] += en_count[i]
        elif int(i)>30 and int(i)<=40:
            en_count2['40'] += en_count[i]
        elif int(i)>40 and int(i)<=50:
            en_count2['50'] += en_count[i]
        elif int(i)>50 and int(i)<=60:
            en_count2['60'] += en_count[i]
        elif int(i)>60 and int(i)<=70:
            en_count2['70'] += en_count[i]
        elif int(i)>70 and int(i)<=80:
            en_count2['80'] += en_count[i]
        elif int(i)>80 and int(i)<=90:
            en_count2['90'] += en_count[i]
        elif int(i)>90 and int(i)<=100:
            en_count2['100'] += en_count[i]
        elif int(i)>100 and int(i)<=200:
            en_count2['200'] += en_count[i]
        elif int(i)>200 and int(i)<=300:
            en_count2['300'] += en_count[i]
        elif int(i)>300 and int(i)<=400:
            en_count2['400'] += en_count[i]
        elif int(i)>400 and int(i)<=500:
            en_count2['500'] += en_count[i]
        elif int(i)>500 and int(i)<=600:
            en_count2['600'] += en_count[i]
        elif int(i)>600 and int(i)<=700:
            en_count2['700'] += en_count[i]
        elif int(i)>700 and int(i)<=800:
            en_count2['800'] += en_count[i]
        elif int(i)>800 and int(i)<=900:
            en_count2['900'] += en_count[i]
        elif int(i)>900 and int(i)<=1000:
            en_count2['1000'] += en_count[i]
        elif int(i)>1000 and int(i)<=2000:
            en_count2['2000'] += en_count[i]
        elif int(i)>2000 and int(i)<=3000:
            en_count2['3000'] += en_count[i]
        elif int(i)>3000 and int(i)<=4000:
            en_count2['4000'] += en_count[i]
        elif int(i)>4000 and int(i)<=5000:
            en_count2['5000'] += en_count[i]
    for i in en_count2:
        f2.write(i + '\t' + str(en_count2[i])+'\n')
    

#train 4835136
#dev 2216
#test 4445

