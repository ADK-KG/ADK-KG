import os
import sys
import json
#with open('user_id_add.json', 'r',encoding='utf-8') as fuserid:
    #userid = json.load(fuserid)





rel_list = {}
f0 = open("relation2id.txt",encoding='utf-8')
line00 = f0.readline()
line01 = f0.readline()
line02 = f0.readline()
line0 = f0.readline()
while line0: 
    line0 = line0.strip('\n')
    relation,rid= line0.split('\t')
    rel_list[relation] = 0
    line0 = f0.readline()
#print(rel_list)


f1 = open("raw.kb",encoding='utf-8')
line_0 = f1.readline()
while line_0: 
    line_0 = line_0.strip('\n')
    en1,en2,rel= line_0.split('\t')
    rel_list[rel]+=1
    line_0 = f1.readline()
#print(rel_list)
few_shot = {}
for item in rel_list:
    if rel_list[item] <= 137 and rel_list[item]>50:
        few_shot[item] = rel_list[item]
print(few_shot)
print(len(few_shot))